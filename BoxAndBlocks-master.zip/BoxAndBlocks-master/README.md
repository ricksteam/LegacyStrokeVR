# BoxAndBlocks
This project is part of a group of Unity Engine built Oculus Rift VR games for stroke patient rehabilitation. 
-----
Box and Blocks is a standardized test for determining a patient's coordination over time.
This project contains the VR equivalent of the Box and Blocks test, and it is useful for comparing 
the effectiveness of VR in therapy compared to other, non-VR methods.
