﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CenterPlayer : MonoBehaviour {

    public Transform player;
    public GameObject box;
	// Use this for initialization
	void Start () {
        //box.transform.position = new Vector3(player.transform.position.x + 0.5f, box.transform.position.y, box.transform.position.z);

	}
	
	
}
