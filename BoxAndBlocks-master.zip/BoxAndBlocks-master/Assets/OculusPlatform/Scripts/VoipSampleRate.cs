// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum VoipSampleRate : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("HZ24000")]
    HZ24000,

    [Description("HZ44100")]
    HZ44100,

    [Description("HZ48000")]
    HZ48000,

  }

}
