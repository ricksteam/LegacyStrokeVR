﻿using System;

public class OvrAvatarAsset {
    public UInt64 assetID;
}
